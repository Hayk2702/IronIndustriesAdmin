<template>
    <div>
        <div>
            <SearchComponent
                ref="SearchComponent"
                @filter-updated="updateFilter"
                :keys="fields.filter(item=>{return item.key != 'actions'})"
                :isCondition=false
                :isAction=false
            ></SearchComponent>
        </div>
        <div class="row justify-content-center" :style="{ 'pointer-events': isLoading ? 'none' : 'auto' }">
            <div>
                <b-row class="justify-content-end">
                    <b-col sm="5" md="5" class="d-flex table_navigate justify-content-end pb-1">
                        <b-button
                            size="sm"
                            class="addButton toggleTableBtm"
                            @click="toggleTable"
                        >
                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor"
                                 class="bi bi-border-all" viewBox="0 0 16 16">
                                <path
                                    d="M0 0h16v16H0V0zm1 1v6.5h6.5V1H1zm7.5 0v6.5H15V1H8.5zM15 8.5H8.5V15H15V8.5zM7.5 15V8.5H1V15h6.5z"/>
                            </svg>
                        </b-button>
                        <div v-if="can('createusers')" class="col-md-1">
                            <a class="btn btnAdd" href="javascript:void(0)" @click="showAddOrEditForm()">
                                {{ __(('variable.add')) }} </a>
                        </div>
                    </b-col>
                </b-row>
                <div class="parent_card_pagination">
                    <div class="card">
                        <div>
                            <b-table
                                :class="showTableLine ? 'table_line': 'table_grid'"
                                :stacked="!showTableLine"
                                :responsive="showTableLine"
                                ref="table"
                                :busy="isBusy"
                                :hover="showTableLine"
                                :items="getData"
                                :fields="fields"
                                :sort-by.sync="sortBy"
                                :sort-desc.sync="sortDesc"
                                :apiUrl="getRout('users.index',{locale : lang})"
                                :perPage="paginate.perPage"
                                :currentPage="paginate.currentPage"
                                :striped="showTableLine"
                                :small="showTableLine"
                                :bordered="showTableLine"
                                :filter="filter"
                                @row-clicked="can('editusers') ?  showAddOrEditForm($event, 'edit') : ''"
                            >
                                <template #table-busy>
                                    <div class="text-center text-danger my-2">
                                        <b-spinner class="align-middle"></b-spinner>
                                        <strong>{{ __(('variable.loaded')) }}</strong></div>
                                </template>
                                <template v-if="!isLoading" #cell(actions)="row">
                                    <a v-if="can('editusers')" class="btn btn-inverse-warning  p-1 a_position"
                                       href="javascript:void(0)" @click="showAddOrEditForm(row.item, 'edit')">
                                        <i class="bi bi-pencil title_hov_top" :data-title="__(('variable.edit'))">
                                            <svg v-b-tooltip.hover
                                                 xmlns="http://www.w3.org/2000/svg" width="24" height="24"
                                                 fill="currentColor"
                                                 class="bi bi-pencil" viewBox="0 0 16 16">
                                                <path
                                                    d="M12.146.146a.5.5 0 0 1 .708 0l3 3a.5.5 0 0 1 0 .708l-10 10a.5.5 0 0 1-.168.11l-5 2a.5.5 0 0 1-.65-.65l2-5a.5.5 0 0 1 .11-.168l10-10zM11.207 2.5 13.5 4.793 14.793 3.5 12.5 1.207 11.207 2.5zm1.586 3L10.5 3.207 4 9.707V10h.5a.5.5 0 0 1 .5.5v.5h.5a.5.5 0 0 1 .5.5v.5h.293l6.5-6.5zm-9.761 5.175-.106.106-1.528 3.821 3.821-1.528.106-.106A.5.5 0 0 1 5 12.5V12h-.5a.5.5 0 0 1-.5-.5V11h-.5a.5.5 0 0 1-.468-.325z"/>
                                            </svg>
                                        </i>
                                    </a>
                                    <button v-if="can('deleteusers')" class="btn btn-danger p-1 a_position"
                                            @click="destroyItem(row.item.id)">
                                        <i class="bi bi-trash title_hov_top" :data-title="__(('variable.remove'))">
                                            <svg v-b-tooltip.hover
                                                 xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="red"
                                                 class="bi bi-trash" viewBox="0 0 16 16">
                                                <path
                                                    d="M5.5 5.5A.5.5 0 0 1 6 6v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5zm2.5 0a.5.5 0 0 1 .5.5v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5zm3 .5a.5.5 0 0 0-1 0v6a.5.5 0 0 0 1 0V6z"/>
                                                <path fill-rule="evenodd"
                                                      d="M14.5 3a1 1 0 0 1-1 1H13v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V4h-.5a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1H6a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1h3.5a1 1 0 0 1 1 1v1zM4.118 4 4 4.059V13a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1V4.059L11.882 4H4.118zM2.5 3V2h11v1h-11z"/>
                                            </svg>
                                        </i>
                                    </button>
                                </template>
                            </b-table>
                        </div>
                    </div>
                    <PaginationComponent ref="PaginationComponent" v-if="Object.keys(users).length > 0"
                                         :paginate="paginate"
                                         @loadAfterChangePage="loadAfterChangePage">
                    </PaginationComponent>
                </div>
                <b-modal
                    class="addModal"
                    v-model="show"
                    :header-text-variant="headerTextVariant"
                    :header-bg-variant="headerBgVariant"
                >
                    <template #modal-title>
                        <b-row>
                            <b-col sm="10" md="10" class="title_popup fs-15 lh-2">{{
                                    ((addOrEdit == 'add') ? __(('variable.add')) :
                                        __(('variable.edit'))) + " " + __(('variable.user'))
                                }}
                            </b-col>
                        </b-row>
                    </template>
                    <b-container fluid>
                        <b-row class="mb-1 bRowPosition">
                            <b-col class='blockInput title_hov_center' v-b-tooltip.hover
                                   :data-title="__(('variable.name'))">
                                <b-form-input
                                    :class="[errors['name'] ? 'error-border': '', 'addFormInputs']"
                                    v-model="user.name"
                                    type="text"
                                    :placeholder="__(('variable.name'))"
                                ></b-form-input>
                                <small v-if="errors['name']" class="error-msg">{{ errors['name'] }}</small>
                            </b-col>
                        </b-row>
                        <b-row class="mb-1 bRowPosition">
                            <b-col class='blockInput title_hov_center' v-b-tooltip.hover
                                   :data-title="__(('variable.email'))">
                                <b-form-input
                                    :class="[errors['email'] ? 'error-border': '', 'addFormInputs']"
                                    v-model="user.email"
                                    type="text"
                                    :placeholder="__(('variable.email'))"
                                ></b-form-input>
                                <small v-if="errors['email']" class="error-msg">{{ errors['email'] }}</small>
                            </b-col>
                        </b-row>
                        <b-row class="mb-1 bRowPosition">
                            <b-col class='blockInput title_hov_center' v-b-tooltip.hover
                                   :data-title="__(('variable.password'))">
                                <b-form-input
                                    type="password"
                                    :class="[errors['password'] ? 'error-border': '', 'addFormInputs']"
                                    v-model="user.password"
                                    :placeholder="__(('variable.password'))"

                                ></b-form-input>
                                <small v-if="errors['password']" class="error-msg">{{ errors['password'] }}</small>
                            </b-col>
                        </b-row>
                        <b-row class="mb-1 bRowPosition">
                            <b-col class='blockInput title_hov_center' v-b-tooltip.hover
                                   :data-title="__(('variable.repeat_password'))">
                                <b-form-input
                                    type="password"
                                    :class="[errors['password_confirmation'] ? 'error-border': '', 'addFormInputs']"
                                    v-model="user.password_confirmation"
                                    :placeholder="__(('variable.repeat_password'))"
                                ></b-form-input>
                                <small v-if="errors['password_confirmation']" class="error-msg">
                                    {{ errors['password_confirmation'] }}
                                </small>
                            </b-col>
                        </b-row>
                        <b-row class="mb-1 bRowPosition">
                            <b-col class='blockInput title_hov_center' v-b-tooltip.hover
                                   :data-title="__(('variable.role'))">
                                <multiselect class="mb-3"
                                             v-model="user.role_id"
                                             :options="gRoles.map(item => item = {value: item.id, text : item.name})"
                                             :multiple="true"
                                             label="text"
                                             track-by="value"
                                             :selectedLabel="__(('variable.selected'))"
                                             :selectLabel="__(('variable.select'))"
                                             :deselectLabel="__(('variable.remove'))"
                                             :placeholder="__(('variable.role'))"
                                             :showNoResults="false"
                                             :class="[errors['role_id'] ? 'error-border': '', '']"
                                >
                                </multiselect>
                                <small v-if="errors['role_id']" class="error-msg">{{ errors['role_id'] }}</small>
                            </b-col>
                        </b-row>
                        <b-row class="mb-1 bRowPosition">
                            <b-col class='blockInput title_hov_center' v-b-tooltip.hover
                                   :data-title="__(('variable.permission'))">
                                <multiselect class="mb-3"
                                             v-model="user.permission_id"
                                             :options="permissions.map(item => item = {value: item.id, text : item.name})"
                                             :multiple="true"
                                             label="text"
                                             track-by="value"
                                             :selectedLabel="__(('variable.selected'))"
                                             :selectLabel="__(('variable.select'))"
                                             :deselectLabel="__(('variable.remove'))"
                                             :placeholder="__(('variable.permission'))"
                                             :showNoResults="false"
                                             :class="[errors['permission_id'] ? 'error-border': '', '']"
                                >
                                </multiselect>
                                <small v-if="errors['permission_id']" class="error-msg">{{ errors['permission_id'] }}
                                </small>
                            </b-col>
                        </b-row>
                    </b-container>

                    <template #modal-footer>
                        <div class="w-100 handle_button">
                            <b-button
                                :disabled="buttonDisabled"
                                size="sm"
                                class="float-right addButton"
                                @click="sendData(user_id)"
                            >
                                {{ ((addOrEdit == 'add') ? __(('variable.add')) : __(('variable.edit'))) }}
                            </b-button>
                        </div>
                    </template>
                </b-modal>

            </div>
        </div>
        <div v-if="isLoading" class="loading-overflow">
            <vue-loading class="loading" type="balls" color="#d9544e"
                         :size="{ width: '100px', height: '100px' }"></vue-loading>
        </div>
    </div>
</template>

<script>

import axios from 'axios';
import Swal from 'sweetalert2/dist/sweetalert2.js';
import 'sweetalert2/src/sweetalert2.scss';
import {VueLoading} from 'vue-loading-template'
import Multiselect from 'vue-multiselect';
import PaginationComponent from "./PaginationComponent";
import SearchComponent from "./SearchComponent";

export default {

    components: {
        Swal,
        Multiselect,
        PaginationComponent,
        SearchComponent,
        VueLoading,
    },

    name: "usersComponent",

    props: [
        'locale',
        'authuser',
        'roles',
    ],

    watch: {

        locale: function (newVal, oldVal) {
            this.lang = newVal;
        },

        authuser: function (newVal, oldVal) {
            this.authUser = newVal;
        },

        roles: function (newVal, oldVal) {
            this.role = newVal;
        },

        filter: {
            handler(newVal, oldVal) {
                this.paginate.currentPage = 1;
            },
            deep: true,
        },
    },

    data() {
        return {
            //default
            lang: this.locale,
            authUser: this.authuser,
            role: this.roles,
            paginate: {
                perPage: 10,
                currentPage: 1,
                total: '',
                currentPageInput: '',
                lastPage: '',
            },
            errors: {},
            //default

            //BTable
            showTableLine: true,
            fields: [
                {
                    key: 'id',
                    label: this.__('variable.id'),
                    sortable: true
                },
                {
                    key: 'name',
                    label: this.__('variable.name'),
                    sortable: true, formatter: (val, key, row) => {
                        return val ? val : '';
                    }
                },
                {
                    key: 'email',
                    label: this.__('variable.email'),
                    sortable: true
                },
                {
                    key: 'actions',
                    label: this.__('variable.action'),
                    sortable: false,
                    formatter: (val, key, row) => {
                        return '';
                    }
                }
            ],
            isBusy: false,
            total: '',
            sortBy: 'id',
            sortDesc: false,
            filter: [
                {
                    text: '',
                    key: '',
                }
            ],
            //BTable

            //Modal
            show: false,
            headerBgVariant: 'custom',
            headerTextVariant: 'white',
            //Modal

            //Data
            gRoles: [],
            permissions: [],
            users: [],
            user: {
                name: '',
                role_id: [],
                permission_id: [],
                email: '',
                password: '',
                password_confirmation: '',
            },
            user_id: '',
            addOrEdit: 'add',
            buttonDisabled: false,
            isLoading: false,
            //Data


        }
    },

    mounted() {
    },

    created() {
    },

    methods: {

        updateFilter(newFilter) {
            this.filter = newFilter;
        },

        toggleTable() {
            this.showTableLine = !this.showTableLine;
        },

        loadAfterChangePage(currentPage, perPage) {
            if (currentPage) {
                this.paginate.currentPage = currentPage;
            }
            if (perPage) {
                this.paginate.perPage = perPage;

            }
        },

        getData(data) {
            let self = this;
            return axios.get(route('users.index', {locale: self.lang}) + `?page=${data.currentPage}`, {params: data})
                .then((resp) => {
                    if (resp && resp.data && resp.data.data) {
                        self.users = resp.data.data;
                        self.paginate.rows = resp.data.total;
                        self.paginate.total = resp.data.total;
                        self.paginate.currentPage = resp.data.current_page;
                        self.paginate.currentPageInput = self.paginate.currentPage;
                        self.paginate.lastPage = resp.data.last_page;
                        self.isBusy = false;
                        return self.users;
                    }
                })

                .catch((err) => {
                    self.showCatchError(err);
                });
        },

        sendData(id) {
            if (this.buttonDisabled) {
                return;
            }
            this.buttonDisabled = true;
            let self = this;
            self.errors = {};
            let data = Object.assign({}, self.user);
            let arrRole = [];
            self.user.role_id.forEach(row => {
                arrRole.push(row.value)
            });
            data.role_id = arrRole;
            let arrPerm = [];
            self.user.permission_id.forEach(row => {
                arrPerm.push(row.value)
            });
            data.permission_id = arrPerm;
            if (self.isSuperAdmin()) {
                data.organization_id = self.user.organization_id ? self.user.organization_id.value : '';
            }
            data.branch_id = self.user.branch_id ? self.user.branch_id.value : '';
            if (id) {
                data.id = id;
            }
            axios.post(route('users.store', {locale: self.lang}), data)
                .then((data) => {
                    if (data && data.data && data.data.isSuccess) {
                        self.show = false;
                        self.resetData();
                        self.$refs.table.refresh();
                    }
                    this.buttonDisabled = false;
                })
                .catch((err) => {
                    if (err && err.response && err.response.data) {
                        let errors = err.response.data;
                        for (let i in errors) {
                            Vue.set(self.errors, i, errors[i][0]);
                        }
                    }
                    this.buttonDisabled = false;

                })
        },

        showAddOrEditForm(obj = '', addOrEdit = 'add') {

            let self = this;
            self.errors = {};
            self.getRoles();
            self.getPermissions();
            self.addOrEdit = addOrEdit;
            self.user_id = obj ? obj.id : "";
            self.user.name = obj ? obj.name : "";
            self.user.email = obj ? obj.email : "";
            self.user.role_id = [];
            if (obj && obj.roles && obj.roles.length) {
                obj.roles.forEach(rol => {
                    self.user.role_id.push({value: rol.id, text: rol.name})
                });
            }
            self.user.permission_id = [];
            if (obj && obj.permissions && obj.permissions.length) {
                obj.permissions.forEach(perm => {
                    this.user.permission_id.push({value: perm.id, text: perm.name})
                });
            }

            self.show = true;
        },

        resetData() {
            let self = this;
            self.errors = {};
            self.users = [];
            self.user = {
                name: '',
                email: '',
                password: '',
                password_confirmation: '',
                role_id: [],
                permission_id: [],
            };
            self.user_id = '';
            self.addOrEdit = 'add';
            self.buttonDisabled = false;
            self.gRoles = [];
            self.permissions = [];
            self.show = false;
        },

        getRoles() {
            let self = this;
            axios.get(route('getRoles', {locale: self.lang}))
                .then((resp) => {
                    if (resp && resp.data) {
                        self.gRoles = resp.data;
                    }
                })
                .catch((err) => {
                    self.showCatchError(err);
                });
        },

        getPermissions() {
            let self = this;
            axios.get(route('getPermissions', {locale: self.lang}))
                .then((resp) => {
                    if (resp && resp.data) {
                        self.permissions = resp.data;
                    }
                })
                .catch((err) => {
                    self.showCatchError(err);
                });
        },

        isSuperAdmin() {
            let self = this;
            let resp = false;
            self.role.forEach(row => {
                if (row.slug == "superadmin") {
                    resp = true;
                }
            });
            return resp;
        },

        destroyItem(id) {
            let self = this;
            Swal.fire({
                title: this.__('variable.sure'),
                text: "",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: this.__('variable.yes'),
                cancelButtonText: this.__('variable.no'),
            }).then((result) => {
                if (result.isConfirmed) {
                    axios.delete(route('users.destroy', {locale: self.lang, user: id}))
                        .then((data) => {
                            if (data && data.data && data.data.isSuccess) {
                                if (this.paginate.perPage == 1) {
                                    this.paginate.currentPage--;
                                }
                                self.getData({
                                    currentPage: ((this.paginate.currentPage > 1) ? this.paginate.currentPage : 1),
                                    perPage: this.paginate.perPage, filter: this.filter
                                }).then(function () {
                                    self.show = false;
                                    self.resetData();
                                    self.$refs.table.refresh();

                                });
                                Swal.fire({
                                    title: this.__('variable.success'),
                                    icon: 'success',
                                    timer: 500,
                                    showConfirmButton: false // Hide the "OK" button
                                });
                            } else if (data && data.data && !data.data.isSuccess && data.data.message) {
                                Swal.fire({
                                    title: data.data.message,
                                    confirmButtonText: this.__('variable.ok')
                                });
                            }

                        })
                        .catch((err) => {
                            self.showCatchError(err);
                        })
                }
            })
        },

        getRout(param) {
            return getRout(param)
        },

        showCatchError(err) {
            if (err.response && err.response.data) {
                Swal.fire({
                    icon: 'error',
                    title: `${err.response.data.message}`,
                    confirmButtonText: this.__('variable.ok')
                });
            }
        },

    },
}
</script>

<style scoped>
/* ===== Users page (dark / glass) ===== */
:deep(*) { box-sizing: border-box; }

.users-wrap {
    --bg: #0b1020;
    --panel: rgba(255,255,255,.06);
    --panel2: rgba(255,255,255,.08);
    --border: rgba(255,255,255,.11);
    --text: rgba(255,255,255,.92);
    --muted: rgba(255,255,255,.62);
    --brand: #7c3aed;
    --brand2: #06b6d4;
    --danger: #ff5a6a;
    --shadow: 0 22px 60px rgba(0,0,0,.45);
    --r: 18px;

    padding: 14px;
    color: var(--text);
}

/* Your current root is <div> without a class, so style common blocks */
.parent_card_pagination {
    margin-top: 12px;
}

.card {
    border-radius: var(--r) !important;
    border: 1px solid var(--border) !important;
    background: linear-gradient(180deg, rgba(255,255,255,.06), rgba(255,255,255,.03)) !important;
    box-shadow: var(--shadow) !important;
    overflow: hidden;
}

/* top action row */
.table_navigate {
    gap: 10px;
    align-items: center;
}

/* Toggle button */
.toggleTableBtm,
.addButton {
    border: 1px solid var(--border) !important;
    background: rgba(255,255,255,.05) !important;
    border-radius: 12px !important;
    padding: 8px 10px !important;
    transition: transform .15s ease, background .15s ease, border-color .15s ease;
}

.toggleTableBtm:hover,
.addButton:hover {
    transform: translateY(-1px);
    background: rgba(255,255,255,.08) !important;
    border-color: rgba(124,58,237,.35) !important;
}

/* Old "btnAdd" links */
.btnAdd,
.btnAdd:link,
.btnAdd:visited {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
    height: 36px;
    padding: 0 12px;
    border-radius: 12px;
    border: 1px solid var(--border);
    background: rgba(255,255,255,.05);
    color: var(--text);
    text-decoration: none;
    font-weight: 800;
    font-size: 12px;
    letter-spacing: .2px;
    transition: transform .15s ease, background .15s ease, border-color .15s ease;
}

.btnAdd:hover {
    transform: translateY(-1px);
    border-color: rgba(6,182,212,.35);
    background: rgba(255,255,255,.08);
}

/* Table modes */
.table_line,
.table_grid {
    width: 100%;
    margin: 0;
    color: var(--text);
}

/* BootstrapVue table (deep because generated markup) */
:deep(.table) {
    margin-bottom: 0 !important;
    color: var(--text) !important;
}

:deep(.table thead th) {
    position: sticky;
    top: 0;
    z-index: 2;
    backdrop-filter: blur(10px);
    -webkit-backdrop-filter: blur(10px);
    border-color: rgba(255,255,255,.08) !important;
    color: rgba(255,255,255,.82) !important;
    font-weight: 900;
    letter-spacing: .25px;
    font-size: 12px;
    text-transform: uppercase;
}

:deep(.table td),
:deep(.table th) {
    border-color: rgba(255,255,255,.08) !important;
    vertical-align: middle !important;
}

:deep(.table tbody tr) {
    transition: background .15s ease;
}

 :deep(.table-striped > tbody > tr:nth-of-type(odd)){
    background: rgba(255,255,255,.03) !important;
}
:deep(.table-striped > tbody > tr:nth-of-type(even)){
    background: rgba(255,255,255,.01) !important;
}
:deep(.table-striped > tbody > tr > td){
    background: transparent !important; /* keep row bg visible */
    color: white;
}
:deep(.table-hover tbody tr:hover) {
    background: rgba(255,255,255,.05) !important;
}

/* Actions buttons */
.a_position {
    border-radius: 12px !important;
}

:deep(.btn-inverse-warning) {
    border: 1px solid rgba(245, 158, 11, .35) !important;
    background: rgba(245, 158, 11, .12) !important;
    color: rgba(255,255,255,.92) !important;
}

:deep(.btn-danger) {
    border: 1px solid rgba(255, 90, 106, .35) !important;
    background: rgba(255, 90, 106, .12) !important;
}

/* Busy state */
:deep(.b-table-busy-slot) {
    padding: 18px 0;
}

/* Modal */
:deep(.modal-content) {
    border-radius: 18px !important;
    border: 1px solid var(--border) !important;
    background: rgba(15, 22, 48, .92) !important;
    color: var(--text) !important;
    box-shadow: var(--shadow) !important;
}

:deep(.modal-header) {
    border-bottom: 1px solid rgba(255,255,255,.08) !important;
}

:deep(.modal-footer) {
    border-top: 1px solid rgba(255,255,255,.08) !important;
}

.title_popup {
    font-weight: 900;
}

/* Inputs */
.addFormInputs,
:deep(.form-control) {
    border-radius: 12px !important;
    border: 1px solid rgba(255,255,255,.12) !important;
    background: rgba(255,255,255,.05) !important;
    color: rgba(255,255,255,.92) !important;
}

.addFormInputs::placeholder,
:deep(.form-control::placeholder) {
    color: rgba(255,255,255,.45) !important;
}

.addFormInputs:focus,
:deep(.form-control:focus) {
    box-shadow: 0 0 0 4px rgba(124,58,237,.18) !important;
    border-color: rgba(124,58,237,.45) !important;
}

.error-border {
    border-color: rgba(255, 90, 106, .55) !important;
}

.error-msg {
    display: block;
    margin-top: 6px;
    color: rgba(255, 90, 106, .95);
    font-weight: 700;
    font-size: 12px;
}

/* Multiselect */
:deep(.multiselect) {
    border-radius: 12px !important;
}
:deep(.multiselect__tags) {
    border-radius: 12px !important;
    border: 1px solid rgba(255,255,255,.12) !important;
    background: rgba(255,255,255,.05) !important;
    color: rgba(255,255,255,.92) !important;
    min-height: 42px;
    padding: 8px 10px !important;
}
:deep(.multiselect__input),
:deep(.multiselect__single) {
    background: transparent !important;
    color: rgba(255,255,255,.92) !important;
}
:deep(.multiselect__content-wrapper) {
    border-radius: 14px !important;
    border: 1px solid rgba(255,255,255,.12) !important;
    background: rgba(15, 22, 48, .98) !important;
    box-shadow: var(--shadow) !important;
}
:deep(.multiselect__option--highlight) {
    background: rgba(124,58,237,.25) !important;
}
:deep(.multiselect__option--selected) {
    background: rgba(6,182,212,.18) !important;
}

/* Loading overlay */
.loading-overflow {
    position: fixed;
    inset: 0;
    background: rgba(0,0,0,.55);
    backdrop-filter: blur(6px);
    -webkit-backdrop-filter: blur(6px);
    z-index: 9999;
    display: grid;
    place-items: center;
}

@media (max-width: 768px) {
    .table_navigate {
        flex-wrap: wrap;
        justify-content: flex-start !important;
    }
}
</style>


<template>
    <div class="page">
        <SearchComponent
            ref="SearchComponent"
            @filter-updated="updateFilter"
            :keys="fields.filter(item => item.key !== 'actions')"
            :isCondition="false"
            :isAction="false"
        />

        <div class="row justify-content-center" :style="{ 'pointer-events': isLoading ? 'none' : 'auto' }">
            <div>
                <b-row class="justify-content-end">
                    <b-col sm="5" md="5" class="d-flex table_navigate justify-content-end pb-1">
                        <b-button size="sm" class="addButton toggleTableBtm" @click="toggleTable">
                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor"
                                 class="bi bi-border-all" viewBox="0 0 16 16">
                                <path d="M0 0h16v16H0V0zm1 1v6.5h6.5V1H1zm7.5 0v6.5H15V1H8.5zM15 8.5H8.5V15H15V8.5zM7.5 15V8.5H1V15h6.5z"/>
                            </svg>
                        </b-button>

                        <div v-if="can('createproducts')" class="col-md-1">
                            <a class="btn btnAdd" href="javascript:void(0)" @click="showAddOrEditForm()">
                                {{ __(('variable.add')) }}
                            </a>
                        </div>
                    </b-col>
                </b-row>

                <div class="parent_card_pagination">
                    <div class="card">
                        <b-table
                            :class="showTableLine ? 'table_line' : 'table_grid'"
                            :stacked="!showTableLine"
                            :responsive="showTableLine"
                            ref="table"
                            :busy="isBusy"
                            :hover="showTableLine"
                            :items="getData"
                            :fields="fields"
                            :sort-by.sync="sortBy"
                            :sort-desc.sync="sortDesc"
                            :apiUrl="getRout('products.index',{locale : lang})"
                            :perPage="paginate.perPage"
                            :currentPage="paginate.currentPage"
                            :striped="showTableLine"
                            :small="showTableLine"
                            :bordered="showTableLine"
                            :filter="filter"
                            @row-clicked="can('editproducts') ? showAddOrEditForm($event, 'edit') : ''"
                        >
                            <template #table-busy>
                                <div class="text-center text-danger my-2">
                                    <b-spinner class="align-middle"></b-spinner>
                                    <strong>{{ __(('variable.loaded')) }}</strong>
                                </div>
                            </template>

                            <template #cell(service)="row">
                                <span v-if="row.item.service && row.item.service.title">
                                    {{ row.item.service.title }}
                                </span>
                                <span v-else class="muted">—</span>
                            </template>

                            <template #cell(images)="row">
                                <div class="thumbs" v-if="row.item.images && row.item.images.length">
                                    <img v-for="img in row.item.images.slice(0,3)"
                                         :key="img.id"
                                         :src="img.image_url"
                                         class="thumb"
                                         alt="img" />
                                    <span v-if="row.item.images.length > 3" class="more">
                                        +{{ row.item.images.length - 3 }}
                                    </span>
                                </div>
                                <span v-else class="muted">—</span>
                            </template>

                            <template v-if="!isLoading" #cell(actions)="row">
                                <a v-if="can('editproducts')" class="btn btn-inverse-warning p-1 a_position"
                                   href="javascript:void(0)" @click.stop="showAddOrEditForm(row.item, 'edit')">
                                    ✎
                                </a>

                                <button v-if="can('deleteproducts')" class="btn btn-danger p-1 a_position"
                                        @click.stop="destroyItem(row.item.id)">
                                    🗑
                                </button>
                            </template>
                        </b-table>
                    </div>

                    <PaginationComponent
                        v-if="Object.keys(products).length > 0"
                        :paginate="paginate"
                        @loadAfterChangePage="loadAfterChangePage"
                    />
                </div>

                <!-- Modal -->
                <b-modal class="addModal" v-model="show" :header-text-variant="headerTextVariant" :header-bg-variant="headerBgVariant">
                    <template #modal-title>
                        <b-row>
                            <b-col sm="10" md="10" class="title_popup fs-15 lh-2">
                                {{ (addOrEdit === 'add' ? __(('variable.add')) : __(('variable.edit'))) + " " + __(('variable.product')) }}
                            </b-col>
                        </b-row>
                    </template>

                    <b-container fluid>

                        <!-- title -->
                        <b-row class="mb-1 bRowPosition">
                            <b-col class="blockInput">
                                <label class="lbl">{{ __(('variable.title')) }}</label>
                                <b-form-input
                                    :class="[errors.title ? 'error-border' : '', 'addFormInputs']"
                                    v-model="form.title"
                                    type="text"
                                    :placeholder="__(('variable.title'))"
                                />
                                <small v-if="errors.title" class="error-msg">{{ errors.title }}</small>
                            </b-col>
                        </b-row>

                        <!-- service -->
                        <b-row class="mb-1 bRowPosition">
                            <b-col class="blockInput">
                                <label class="lbl">{{ __(('variable.service')) }}</label>
                                <b-form-select
                                    v-model="form.service_id"
                                    :options="serviceOptions"
                                    class="addFormInputs"
                                />
                                <small v-if="errors.service_id" class="error-msg">{{ errors.service_id }}</small>
                            </b-col>
                        </b-row>

                        <!-- size/weight -->
                        <b-row class="mb-1 bRowPosition">
                            <b-col md="6" class="blockInput">
                                <label class="lbl">{{ __(('variable.size')) }}</label>
                                <b-form-input
                                    v-model="form.size"
                                    class="addFormInputs"
                                    :placeholder="__(('variable.size'))"
                                />
                                <small v-if="errors.size" class="error-msg">{{ errors.size }}</small>
                            </b-col>
                            <b-col md="6" class="blockInput">
                                <label class="lbl">{{ __(('variable.weight')) }}</label>
                                <b-form-input
                                    v-model="form.weight"
                                    class="addFormInputs"
                                    :placeholder="__(('variable.weight'))"
                                />
                                <small v-if="errors.weight" class="error-msg">{{ errors.weight }}</small>
                            </b-col>
                        </b-row>

                        <!-- type/material -->
                        <b-row class="mb-1 bRowPosition">
                            <b-col md="6" class="blockInput">
                                <label class="lbl">{{ __(('variable.type')) }}</label>
                                <b-form-input
                                    v-model="form.type"
                                    class="addFormInputs"
                                    :placeholder="__(('variable.type'))"
                                />
                                <small v-if="errors.type" class="error-msg">{{ errors.type }}</small>
                            </b-col>

                            <b-col md="6" class="blockInput">
                                <label class="lbl">{{ __(('variable.material')) }}</label>
                                <b-form-input
                                    v-model="form.material"
                                    class="addFormInputs"
                                    :placeholder="__(('variable.material'))"
                                />
                                <small v-if="errors.material" class="error-msg">{{ errors.material }}</small>
                            </b-col>
                        </b-row>

                        <!-- images -->
                        <b-row class="mb-1 bRowPosition">
                            <b-col class="blockInput">
                                <label class="lbl">{{ __(('variable.images')) }}</label>

                                <input type="file" class="fileInput" accept="image/*" multiple @change="onFiles" />
                                <small v-if="errors.images" class="error-msg">{{ errors.images }}</small>
                                <small v-if="errors['images.0']" class="error-msg">{{ errors['images.0'] }}</small>

                                <!-- existing images -->
                                <div v-if="existingImages.length" class="previewGrid">
                                    <div v-for="img in existingImages" :key="img.id" class="previewItem">
                                        <img :src="img.image_url" alt="existing" />
                                        <button type="button" class="xBtn" @click="markToDelete(img.id)">×</button>
                                    </div>
                                </div>

                                <!-- new previews -->
                                <div v-if="previewUrls.length" class="previewGrid">
                                    <div v-for="(u,idx) in previewUrls" :key="u" class="previewItem">
                                        <img :src="u" alt="preview" />
                                        <button type="button" class="xBtn" @click="removeNew(idx)">×</button>
                                    </div>
                                </div>
                            </b-col>
                        </b-row>

                        <!-- description -->
                        <b-row class="mb-1 bRowPosition">
                            <b-col class="blockInput">
                                <label class="lbl">{{ __(('variable.description')) }}</label>
                                <ckeditor :editor="editor" v-model="form.description" :config="editorConfig"></ckeditor>
                                <small v-if="errors.description" class="error-msg">{{ errors.description }}</small>
                            </b-col>
                        </b-row>

                    </b-container>

                    <template #modal-footer>
                        <div class="w-100 handle_button">
                            <b-button :disabled="buttonDisabled" size="sm" class="float-right addButton" @click="save">
                                {{ addOrEdit === 'add' ? __(('variable.add')) : __(('variable.edit')) }}
                            </b-button>
                        </div>
                    </template>
                </b-modal>

            </div>
        </div>

        <div v-if="isLoading" class="loading-overflow">
            <vue-loading class="loading" type="balls" color="#d9544e" :size="{ width: '100px', height: '100px' }"></vue-loading>
        </div>
    </div>
</template>

<script>
import axios from "axios";
import Swal from "sweetalert2/dist/sweetalert2.js";
import "sweetalert2/src/sweetalert2.scss";
import { VueLoading } from "vue-loading-template";
import PaginationComponent from "./PaginationComponent";
import SearchComponent from "./SearchComponent";
import ClassicEditor from "@ckeditor/ckeditor5-build-classic";

export default {
    name: "ProductsComponent",
    components: { Swal, VueLoading, PaginationComponent, SearchComponent },
    props: ["locale"],

    data() {
        return {
            lang: this.locale,

            editor: ClassicEditor,
            editorConfig: { placeholder: this.__("variable.description") },

            paginate: {
                perPage: 10,
                currentPage: 1,
                total: "",
                currentPageInput: "",
                lastPage: "",
            },

            fields: [
                { key: "id", label: this.__("variable.id"), sortable: true },
                { key: "title", label: this.__("variable.title"), sortable: true },
                { key: "service", label: this.__("variable.service"), sortable: false },
                { key: "images", label: this.__("variable.images"), sortable: false },
                { key: "actions", label: this.__("variable.action"), sortable: false, formatter: () => "" },
            ],

            isBusy: false,
            sortBy: "id",
            sortDesc: false,
            filter: [{ text: "", key: "" }],

            products: [],
            showTableLine: true,

            // modal
            show: false,
            headerBgVariant: "custom",
            headerTextVariant: "white",
            addOrEdit: "add",

            form: {
                id: null,
                service_id: null,
                title: "",
                description: "",
                size: "",
                weight: "",
                type: "",
                material: "",
            },

            // services list
            services: [],
            serviceOptions: [{ value: null, text: "—" }],

            // images
            newFiles: [],
            previewUrls: [],
            existingImages: [],
            deletedImageIds: [],

            errors: {},
            buttonDisabled: false,
            isLoading: false,
        };
    },

    watch: {
        locale(n) { this.lang = n; },
        filter: {
            handler() { this.paginate.currentPage = 1; },
            deep: true,
        },
    },

    mounted() {
        this.loadServices();
    },

    methods: {
        updateFilter(newFilter) {
            this.filter = newFilter;
        },

        toggleTable() {
            this.showTableLine = !this.showTableLine;
        },

        loadAfterChangePage(currentPage, perPage) {
            if (currentPage) this.paginate.currentPage = currentPage;
            if (perPage) this.paginate.perPage = perPage;
        },

        getData(data) {
            this.isBusy = true;
            return axios
                .get(route("products.index", { locale: this.lang }) + `?page=${data.currentPage}`, { params: data })
                .then((resp) => {
                    if (resp && resp.data && resp.data.data) {
                        this.products = resp.data.data;
                        this.paginate.total = resp.data.total;
                        this.paginate.currentPage = resp.data.current_page;
                        this.paginate.currentPageInput = this.paginate.currentPage;
                        this.paginate.lastPage = resp.data.last_page;
                        this.isBusy = false;
                        return this.products;
                    }
                })
                .catch((err) => {
                    this.isBusy = false;
                    this.showCatchError(err);
                });
        },

        loadServices() {
            // assumes services.index returns {data:[...]} or pagination. If your services index returns paginate, we can fetch large perPage.
            axios.get(route("services.index", { locale: this.lang }), { params: { perPage: 500 } })
                .then((resp) => {
                    const arr = resp?.data?.data || [];
                    this.services = arr;
                    this.serviceOptions = [{ value: null, text: "—" }]
                        .concat(arr.map(s => ({ value: s.id, text: s.title })));
                })
                .catch(() => {
                    // ignore, still usable without select data
                });
        },

        showAddOrEditForm(obj = null, mode = "add") {
            this.errors = {};
            this.addOrEdit = mode;

            this.form = {
                id: obj ? obj.id : null,
                service_id: obj ? (obj.service_id || (obj.service ? obj.service.id : null)) : null,
                title: obj ? obj.title : "",
                description: obj ? (obj.description || "") : "",
                size: obj ? (obj.size || "") : "",
                weight: obj ? (obj.weight ?? "") : "",
                type: obj ? (obj.type || "") : "",
                material: obj ? (obj.material || "") : "",
            };

            // images
            this.newFiles = [];
            this.previewUrls = [];
            this.deletedImageIds = [];
            this.existingImages = (obj && obj.images) ? JSON.parse(JSON.stringify(obj.images)) : [];

            this.show = true;
        },

        onFiles(e) {
            const files = Array.from((e.target.files || []));
            this.newFiles.push(...files);
            files.forEach((f) => this.previewUrls.push(URL.createObjectURL(f)));
            e.target.value = "";
        },

        removeNew(idx) {
            const url = this.previewUrls[idx];
            if (url) URL.revokeObjectURL(url);
            this.previewUrls.splice(idx, 1);
            this.newFiles.splice(idx, 1);
        },

        markToDelete(imageId) {
            this.existingImages = this.existingImages.filter(i => i.id !== imageId);
            if (!this.deletedImageIds.includes(imageId)) this.deletedImageIds.push(imageId);
        },

        save() {
            if (this.buttonDisabled) return;

            this.buttonDisabled = true;
            this.errors = {};
            this.isLoading = true;

            const fd = new FormData();
            if (this.form.id) fd.append("id", this.form.id);

            fd.append("service_id", this.form.service_id || "");
            fd.append("title", this.form.title || "");
            fd.append("description", this.form.description || "");
            fd.append("size", this.form.size || "");
            fd.append("weight", this.form.weight || "");
            fd.append("type", this.form.type || "");
            fd.append("material", this.form.material || "");

            this.deletedImageIds.forEach((id, i) => fd.append(`deleted_image_ids[${i}]`, id));
            this.newFiles.forEach((file) => fd.append("images[]", file));

            axios
                .post(route("products.store", { locale: this.lang }), fd, {
                    headers: { "Content-Type": "multipart/form-data" },
                })
                .then((resp) => {
                    if (resp && resp.data && resp.data.isSuccess) {
                        this.show = false;
                        this.$refs.table.refresh();

                        Swal.fire({
                            title: resp.data.message || this.__("variable.updated_successfully"),
                            icon: "success",
                            timer: 900,
                            showConfirmButton: false,
                        });
                    }
                    this.isLoading = false;
                    this.buttonDisabled = false;
                })
                .catch((err) => {
                    this.isLoading = false;
                    this.buttonDisabled = false;

                    if (err && err.response && err.response.data && typeof err.response.data === "object") {
                        const errors = err.response.data;
                        for (let k in errors) {
                            this.$set(this.errors, k, Array.isArray(errors[k]) ? errors[k][0] : errors[k]);
                        }
                    } else {
                        this.showCatchError(err);
                    }
                });
        },

        destroyItem(id) {
            Swal.fire({
                title: this.__("variable.sure"),
                icon: "warning",
                showCancelButton: true,
                confirmButtonText: this.__("variable.yes"),
                cancelButtonText: this.__("variable.no"),
            }).then((result) => {
                if (!result.isConfirmed) return;

                axios
                    .delete(route("products.destroy", { locale: this.lang, product: id }))
                    .then((resp) => {
                        if (resp && resp.data && resp.data.isSuccess) {
                            this.$refs.table.refresh();
                            Swal.fire({ title: this.__("variable.success"), icon: "success", timer: 600, showConfirmButton: false });
                        }
                    })
                    .catch((err) => this.showCatchError(err));
            });
        },

        getRout(param) {
            return getRout(param);
        },

        showCatchError(err) {
            if (err.response && err.response.data) {
                Swal.fire({
                    icon: "error",
                    title: `${err.response.data.message}`,
                    confirmButtonText: this.__("variable.ok"),
                });
            }
        },
    },
};
</script>

<style scoped>
/* reuse same clean “page” style you already fixed for Services */
:deep(*) { box-sizing: border-box; }

.page{
    --border: rgba(255,255,255,.11);
    --text: rgba(255,255,255,.92);
    --muted: rgba(255,255,255,.62);
    --shadow: 0 22px 60px rgba(0,0,0,.45);
    --r: 18px;

    padding: 14px;
    color: var(--text);
}

.parent_card_pagination { margin-top: 12px; }

.card {
    border-radius: var(--r) !important;
    border: 1px solid var(--border) !important;
    background: linear-gradient(180deg, rgba(255,255,255,.06), rgba(255,255,255,.03)) !important;
    box-shadow: var(--shadow) !important;
    overflow: hidden;
}

.table_navigate { gap: 10px; align-items: center; }

.toggleTableBtm,
.addButton,
.btnAdd{
    border: 1px solid rgba(255,255,255,.12) !important;
    background: rgba(255,255,255,.05) !important;
    color: var(--text) !important;
    border-radius: 12px !important;
    transition: transform .15s ease, background .15s ease, border-color .15s ease;
}
.toggleTableBtm,
.addButton { padding: 8px 10px !important; }

.btnAdd{
    display: inline-flex;
    align-items: center;
    justify-content: center;
    height: 36px;
    padding: 0 12px !important;
    text-decoration: none !important;
    font-weight: 800;
    font-size: 12px;
}
.toggleTableBtm:hover,
.addButton:hover,
.btnAdd:hover{
    transform: translateY(-1px);
    background: rgba(255,255,255,.08) !important;
    border-color: rgba(124,58,237,.45) !important;
}

/* table */
.table_line,.table_grid{ width:100%; margin:0; }
:deep(.table){ margin-bottom:0!important; color:var(--text)!important; }
:deep(.table thead th){
    position: sticky; top:0; z-index:2;
    backdrop-filter: blur(10px);
    border-color: rgba(255,255,255,.08)!important;
    color: rgba(255,255,255,.82)!important;
    font-weight:900; font-size:12px; text-transform:uppercase; letter-spacing:.25px;
}
:deep(.table td),:deep(.table th){ border-color: rgba(255,255,255,.08)!important; vertical-align: middle!important; }
:deep(.table-striped > tbody > tr:nth-of-type(odd)){ background: rgba(255,255,255,.03)!important; }
:deep(.table-striped > tbody > tr:nth-of-type(even)){ background: rgba(255,255,255,.01)!important; }
:deep(.table-striped > tbody > tr > td) {
    background: transparent !important;
    color: var(--text);
}
:deep(.table-hover tbody tr:hover){ background: rgba(255,255,255,.05)!important; }

/* thumbs */
.thumbs{ display:flex; align-items:center; gap:6px; }
.thumb{ width:28px; height:28px; object-fit:cover; border-radius:8px; border:1px solid rgba(255,255,255,.12); }
.more{ font-size:12px; color: rgba(255,255,255,.6); }
.muted{ color: rgba(255,255,255,.55); }

/* modal */
:deep(.modal-content){
    border-radius: 18px !important;
    border: 1px solid var(--border) !important;
    background: rgba(15, 22, 48, .92) !important;
    color: var(--text) !important;
    box-shadow: var(--shadow) !important;
}
:deep(.modal-header){ border-bottom: 1px solid rgba(255,255,255,.08)!important; }
:deep(.modal-footer){ border-top: 1px solid rgba(255,255,255,.08)!important; }
.title_popup{ font-weight:900; }

/* inputs */
.lbl{ display:block; font-size:12px; font-weight:900; color: var(--muted); margin-bottom:6px; }
.addFormInputs,:deep(.form-control){
    border-radius: 12px !important;
    border: 1px solid rgba(255,255,255,.12) !important;
    background: rgba(255,255,255,.05) !important;
    color: var(--text) !important;
}
.addFormInputs::placeholder,:deep(.form-control::placeholder){ color: rgba(255,255,255,.45)!important; }

.fileInput{
    width:100%;
    padding:10px;
    border-radius:12px;
    border:1px solid rgba(255,255,255,.12);
    background: rgba(255,255,255,.04);
    color: rgba(255,255,255,.85);
}

/* previews */
.previewGrid{
    margin-top:10px;
    display:grid;
    grid-template-columns: repeat(auto-fill, minmax(120px,1fr));
    gap:10px;
}
.previewItem{
    position:relative;
    border:1px solid rgba(255,255,255,.10);
    border-radius:14px;
    overflow:hidden;
    background: rgba(255,255,255,.03);
}
.previewItem img{
    width:100%;
    height:110px;
    object-fit:cover;
    display:block;
}
.xBtn{
    position:absolute;
    top:6px;
    right:6px;
    width:28px;
    height:28px;
    border-radius:10px;
    border:1px solid rgba(255,255,255,.15);
    background: rgba(0,0,0,.45);
    color:white;
    font-size:18px;
    line-height:1;
}

/* errors */
.error-border{ border-color: rgba(255, 90, 106, .55) !important; }
.error-msg{ display:block; margin-top:6px; color: rgba(255, 90, 106, .95); font-weight:800; font-size:12px; }

/* ckeditor */
:deep(.ck-editor__editable){
    min-height:220px;
    background: rgba(15,22,48,.95) !important;
    color: rgba(255,255,255,.92) !important;
    border-radius:12px !important;
}
:deep(.ck-toolbar){
    background: rgba(20,28,60,.95) !important;
    border: 1px solid rgba(255,255,255,.12) !important;
    border-radius: 12px 12px 0 0 !important;
}

/* loading */
.loading-overflow{
    position: fixed;
    inset:0;
    background: rgba(0,0,0,.55);
    backdrop-filter: blur(6px);
    z-index:9999;
    display:grid;
    place-items:center;
}
</style>

<?php

use App\Http\Controllers\ApiController;
use Illuminate\Support\Facades\Route;


Route::group(['prefix' => '/', 'middleware' => 'blockcors'], function () {

    Route::group(['middleware' => ['loggable']], function () {

        Route::post('test', [ApiController::class, 'test'])->name("test");


    });



});


